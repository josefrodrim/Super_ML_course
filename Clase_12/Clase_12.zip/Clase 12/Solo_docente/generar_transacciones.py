"""Genera el transaccional sintético de tarjetas (Clase 12 RFM; reutilizable en fraude y grafos)."""
import numpy as np, pandas as pd
rng = np.random.default_rng(2026)
R = "/home/claude/repo/"
seg = pd.read_csv(R + "Clase 10/Data/segmentacion_tarjetas.csv")
real = pd.read_csv(R + "Clase 10/Data/segmentos_reales.csv")
car = pd.read_csv(R + "Clase_9/Datos/cartera_tarjetas.csv")
seg = seg.merge(real, on="id_cliente")
ult = car[car.periodo >= "2026-01"].sort_values("periodo").groupby("id_cliente").tail(1)[["id_cliente", "default_3m", "utilizacion_tc"]]
seg = seg.merge(ult, on="id_cliente", how="left")
n = len(seg)

# ── Comercios ──────────────────────────────────────────────────────────
CIUD = ["Lima", "Arequipa", "Trujillo", "Piura", "Chiclayo", "Cusco", "Huancayo", "Iquitos"]
PC = np.array([.60, .08, .07, .05, .05, .05, .05, .05])
EXT = [("Santiago", "Chile"), ("Miami", "Estados Unidos"), ("Madrid", "España"), ("Ciudad de México", "México"),
       ("Bogotá", "Colombia"), ("Buenos Aires", "Argentina"), ("Nueva York", "Estados Unidos"), ("Cancún", "México")]
NR = {"supermercado": 120, "restaurantes": 600, "tiendas": 500, "servicios": 150, "salud": 150,
      "combustible": 120, "entretenimiento": 130}
rows = []
for rub, k in NR.items():
    for c in rng.choice(CIUD, k, p=PC):
        rows.append((rub, c, "Perú", "presencial"))
for _ in range(110): rows.append(("online", "online", "Perú", "online"))
for _ in range(40):  rows.append(("online", "online", rng.choice(["Estados Unidos", "China", "Reino Unido"]), "online"))
for _ in range(30):  rows.append(("viajes", "online", "Perú", "online"))          # aerolíneas y agencias web
for _ in range(25):  rows.append(("viajes", "Lima", "Perú", "presencial"))
for _ in range(45):
    c, p = EXT[rng.integers(len(EXT))]; rows.append(("viajes", c, p, "presencial"))  # hoteles afuera
for _ in range(90):
    c, p = EXT[rng.integers(len(EXT))]; rows.append((rng.choice(["restaurantes", "tiendas", "entretenimiento"]), c, p, "presencial"))
com = pd.DataFrame(rows, columns=["rubro", "ciudad", "pais", "canal_comercio"])
com = com.sample(frac=1, random_state=7).reset_index(drop=True)
com.insert(0, "id_comercio", [f"C{i:04d}" for i in range(1, len(com) + 1)])
# comercios del fraude: tiendas online del extranjero (electrónica) con poco uso legítimo
fra_targets = []
for i in range(10):
    fid = f"C{len(com) + 1 + i:04d}"
    fra_targets.append(fid)
com = pd.concat([com, pd.DataFrame({"id_comercio": fra_targets, "rubro": "online", "ciudad": "online",
                 "pais": rng.choice(["Estados Unidos", "China", "Hong Kong"], 10), "canal_comercio": "online"})], ignore_index=True)
# comercio comprometido: un grifo de Lima
grifo = com[(com.rubro == "combustible") & (com.ciudad == "Lima")].id_comercio.iloc[3]

# ── Clientes ───────────────────────────────────────────────────────────
seg["ciudad"] = rng.choice(CIUD, n, p=PC)
seg.loc[seg.segmento_real == "Premium viajero", "ciudad"] = rng.choice(CIUD, (seg.segmento_real == "Premium viajero").sum(), p=[.82, .06, .04, .02, .02, .02, .01, .01])
# dispositivos propios (y algunos compartidos en familia)
devs = {}
nd = 0
for i, cid in enumerate(seg.id_cliente):
    k = 1 if rng.random() < .7 else 2
    devs[cid] = [f"D{nd + j + 1:06d}" for j in range(k)]; nd += k
ids = seg.id_cliente.values
for a, b in rng.choice(ids, (110, 2), replace=False):   # parejas que comparten un dispositivo
    devs[b] = devs[b] + [devs[a][0]]

# trayectorias: 15 meses, t = 0 (jul-2025) ... 14 (sep-2026); corte al final de t = 11 (jun-2026)
T = 15
season = np.array([1.12, .98, .97, 1.0, 1.08, 1.35, .9, .88, .95, .98, 1.02, 1.0, 1.12, .98, .97])
mult = np.ones((n, T))
tray = np.array(["estable"] * n, dtype=object)
dflt = seg.default_3m.fillna(0).values == 1
for i in np.where(dflt)[0]:
    if rng.random() < .72:                                  # tarjeta copada: deja de comprar antes del corte
        t0 = rng.integers(6, 10)
        for t in range(t0, T): mult[i, t] = np.exp(-(t - t0 + 1) / 1.1)
        tray[i] = "default_cae"
    else:
        tray[i] = "default_sorpresa"
    mult[i, 12:] = 0                                         # bloqueada tras el default
p_fuga = seg.segmento_real.map({"Digital joven": .2, "Cotidiano": .14, "Premium viajero": .1, "Revolvente": .1,
                                "Usuario de efectivo": .12, "Dormido": .05, "Atípico": .05}).values
for i in np.where(~dflt)[0]:
    u = rng.random()
    if u < p_fuga[i]:
        tc = rng.integers(4, 15)
        for t in range(T):
            if t >= tc: mult[i, t] = .03
            elif t == tc - 1: mult[i, t] = .45
            elif t == tc - 2: mult[i, t] = .75
        tray[i] = "fuga"
    elif u < p_fuga[i] + .10:
        g = rng.uniform(.05, .12)
        mult[i] = np.exp(g * (np.arange(T) - 11)); tray[i] = "crece"
    elif u < p_fuga[i] + .14:                               # se activó hace poco (estaba casi sin uso)
        ta = rng.integers(7, 11); mult[i, :ta] = .04; tray[i] = "reactivado"
mult *= np.exp(rng.normal(0, .18, (n, T)))
lam = np.maximum(seg.num_transacciones_mes.values / 5, .1)
p_off = seg.meses_sin_uso_6m.values / 6
tick = seg.ticket_promedio.values * 5
# mezcla de rubros por cliente
pr = np.c_[seg.pct_supermercado, seg.pct_restaurantes, seg.pct_viajes, seg.pct_online]
resto = np.clip(1 - pr.sum(1), .02, None)
RUB = ["supermercado", "restaurantes", "viajes", "online", "tiendas", "servicios", "salud", "combustible", "entretenimiento"]
FR = np.array([.38, .2, .12, .15, .15])
P = np.c_[pr, resto[:, None] * FR]
P = P / P.sum(1, keepdims=True)
TM = {"supermercado": 1.2, "restaurantes": .6, "viajes": 3.5, "online": 1.0, "tiendas": 1.3,
      "servicios": 1.1, "salud": .9, "combustible": .8, "entretenimiento": .7}

by_rc = {}
for (rub, c), g in com[~com.id_comercio.isin(fra_targets) & (com.pais == "Perú")].groupby(["rubro", "ciudad"]):
    by_rc[(rub, c)] = g.id_comercio.values
ext_com = com[com.pais != "Perú"]
ext_com = ext_com[~ext_com.id_comercio.isin(fra_targets) & (ext_com.canal_comercio == "presencial")]
def pool(rub, ciudad):
    if rub == "online": return by_rc[("online", "online")]
    if rub == "viajes": return np.r_[by_rc[("viajes", "online")], by_rc[("viajes", "Lima")]]
    return by_rc.get((rub, ciudad), by_rc[(rub, "Lima")])
HOUR_P = np.array([.4, .2, .1, .1, .1, .3, .8, 1.5, 2.6, 3.4, 4.2, 5, 6.4, 6.5, 5.2, 4.5, 4.4, 4.8, 5.6, 6.6, 7, 6.2, 4.4, 2.0])
HOUR_P /= HOUR_P.sum()
month_start = pd.date_range("2025-07-01", periods=T, freq="MS")
dim = month_start.days_in_month.values

out = []
favs = {}
for i in range(n):
    cid = ids[i]; ciudad = seg.ciudad.iat[i]
    # favoritos por rubro (Zipf)
    fv = {}
    for rub in RUB:
        pl = pool(rub, ciudad); k = min(len(pl), rng.integers(2, 7))
        fv[rub] = (rng.choice(pl, k, replace=False), 1 / np.arange(1, k + 1) ** 1.1)
    favs[cid] = fv
    # viajes legítimos al extranjero
    viajes = []
    nv = rng.poisson(2.2 if seg.segmento_real.iat[i] == "Premium viajero" else .25)
    for _ in range(nv):
        d0 = pd.Timestamp("2025-07-01") + pd.Timedelta(days=int(rng.integers(0, 450)))
        c, p = EXT[rng.integers(len(EXT))]; viajes.append((d0, d0 + pd.Timedelta(days=int(rng.integers(4, 12))), c))
    for t in range(T):
        if 6 <= t <= 11 and rng.random() < p_off[i]: continue
        if t not in range(6, 12) and rng.random() < p_off[i] * .9: continue
        k = rng.poisson(lam[i] * season[t] * mult[i, t])
        if k == 0: continue
        days = rng.integers(0, dim[t], k); hours = rng.choice(24, k, p=HOUR_P)
        mins = rng.integers(0, 60, k); secs = rng.integers(0, 60, k)
        rubs = rng.choice(9, k, p=P[i])
        for j in range(k):
            ts = month_start[t] + pd.Timedelta(days=int(days[j]), hours=int(hours[j]), minutes=int(mins[j]), seconds=int(secs[j]))
            rub = RUB[rubs[j]]
            en_viaje = [v for v in viajes if v[0] <= ts <= v[1]]
            if en_viaje and rub not in ("online", "servicios") and rng.random() < .85:
                cand = ext_com[ext_com.ciudad == en_viaje[0][2]].id_comercio.values
                cm = rng.choice(cand); canal = "presencial"
            else:
                cs, w = fv[rub]; cm = rng.choice(cs, p=w / w.sum())
                canal = "online" if rub == "online" or cm in by_rc[("viajes", "online")] else ("online" if rub == "servicios" and rng.random() < .35 else "presencial")
            m = tick[i] * TM[rub] * rng.lognormal(0, .55)
            dv = rng.choice(devs[cid]) if canal == "online" else ""
            out.append((cid, ts, round(max(m, 1.5), 2), cm, canal, dv, 0, ""))

# ── Fraude sembrado (para las clases de fraude y grafos) ────────────────
fraude = []
ring = [f"D{900001 + k}" for k in range(6)]
lima_act = seg[(seg.ciudad == "Lima") & (seg.segmento_real != "Dormido") & (~dflt)].id_cliente.values
visit = rng.choice(lima_act, 230, replace=False)
for cid in visit:      # visitas legítimas al grifo comprometido
    ts = pd.Timestamp("2026-02-02") + pd.Timedelta(days=int(rng.integers(0, 19)), hours=int(rng.integers(7, 22)), minutes=int(rng.integers(0, 60)))
    out.append((cid, ts, round(rng.uniform(60, 220), 2), grifo, "presencial", "", 0, ""))
victimas1 = rng.choice(visit, 88, replace=False)
for cid in victimas1:
    d0 = pd.Timestamp("2026-03-01") + pd.Timedelta(days=int(rng.integers(0, 58)))
    dv = rng.choice(ring[:4])
    for q in range(rng.integers(1, 5)):
        ts = d0 + pd.Timedelta(hours=int(rng.integers(0, 30)), minutes=int(rng.integers(0, 60)))
        fraude.append((cid, ts, round(rng.uniform(700, 4800), 2), rng.choice(fra_targets[:6]), "online", dv, 1, "comercio_comprometido"))
otros = np.setdiff1d(seg[(seg.segmento_real != "Dormido") & (~dflt)].id_cliente.values, visit)
victimas2 = rng.choice(otros, 34, replace=False)
for cid in victimas2:   # prueba de tarjeta: montos chicos y luego grandes, desde el anillo
    d0 = pd.Timestamp("2026-04-05") + pd.Timedelta(days=int(rng.integers(0, 70)))
    dv = rng.choice(ring[3:]); h = int(rng.integers(0, 24))
    for q in range(rng.integers(1, 3)):
        fraude.append((cid, d0 + pd.Timedelta(hours=h, minutes=int(rng.integers(0, 20))), round(rng.uniform(1, 5), 2), rng.choice(fra_targets[4:]), "online", dv, 1, "prueba_tarjeta"))
    for q in range(rng.integers(1, 4)):
        fraude.append((cid, d0 + pd.Timedelta(hours=h + 1 + q, minutes=int(rng.integers(0, 60))), round(rng.uniform(900, 5200), 2), rng.choice(fra_targets), "online", dv, 1, "prueba_tarjeta"))
otros2 = np.setdiff1d(otros, victimas2)
victimas3 = rng.choice(otros2, 92, replace=False)
for cid in victimas3:   # tarjeta clonada: presencial en el extranjero, de madrugada
    d0 = pd.Timestamp("2026-01-10") + pd.Timedelta(days=int(rng.integers(0, 165)))
    c, p = EXT[rng.integers(len(EXT))]; cand = ext_com[ext_com.ciudad == c].id_comercio.values
    for q in range(rng.integers(1, 4)):
        ts = d0 + pd.Timedelta(hours=int(rng.integers(1, 6)), minutes=int(rng.integers(0, 60)) + 40 * q)
        fraude.append((cid, ts, round(tick[ids == cid][0] * rng.uniform(4, 12) + rng.uniform(300, 900), 2), rng.choice(cand), "presencial", "", 1, "tarjeta_clonada"))
# algo de uso legítimo de los comercios del fraude (para que no sea trivial)
for cid in rng.choice(seg[seg.pct_online > .3].id_cliente.values, 60, replace=False):
    ts = pd.Timestamp("2025-08-01") + pd.Timedelta(days=int(rng.integers(0, 400)), hours=int(rng.integers(8, 23)))
    out.append((cid, ts, round(rng.uniform(80, 1500), 2), rng.choice(fra_targets), "online", devs[cid][0], 0, ""))

tx = pd.DataFrame(out + fraude, columns=["id_cliente", "fecha_hora", "monto", "id_comercio", "canal", "id_dispositivo", "es_fraude", "patron"])
tx = tx[tx.fecha_hora < "2026-10-01"].sort_values(["fecha_hora", "id_cliente"]).reset_index(drop=True)
tx.insert(0, "id_transaccion", np.arange(1, len(tx) + 1) + 10_000_000)
tx["fecha_hora"] = tx.fecha_hora.dt.strftime("%Y-%m-%d %H:%M:%S")
tx.to_pickle("tx_full.pkl")
pd.DataFrame({"id_cliente": ids, "trayectoria": tray, "ciudad": seg.ciudad}).to_pickle("clientes_aux.pkl")
com.drop(columns="canal_comercio").to_pickle("com.pkl")
print(len(tx), tx.es_fraude.sum(), tx.patron.value_counts().to_dict(), "grifo", grifo)
print(pd.Series(tray).value_counts())
